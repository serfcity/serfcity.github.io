 namespace events
{
    void eventSpooler();
}
