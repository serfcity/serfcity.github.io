namespace window
{
	extern Window main_win;
}
